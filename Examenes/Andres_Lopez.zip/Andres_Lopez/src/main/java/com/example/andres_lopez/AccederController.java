package com.example.andres_lopez;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;

import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;

public class AccederController implements Initializable {

    @FXML
    private TableView tabla;
    @FXML
    private TableColumn nombre,correo,rol;
    @FXML
    private RadioMenuItem guest,user,developer,test,all;

    private ToggleGroup grupoMenus;

    private ObservableList<Usuario>listaUsuarios;

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        instancias();
        asociarDatos();
        acciones();
    }

    private void instancias() {
        grupoMenus = new ToggleGroup();
        grupoMenus.getToggles().addAll(guest,user,developer,test,all);
    }

    private void acciones() {

    }


    private void asociarDatos() {
        nombre.setCellValueFactory(new PropertyValueFactory<>("nombre"));
        correo.setCellValueFactory(new PropertyValueFactory<>("correo"));
        rol.setCellValueFactory(new PropertyValueFactory<>("rol"));
    }

    public void setListaUsuarios(ObservableList<Usuario> listaUsuarios) {
        this.listaUsuarios = listaUsuarios;
        tabla.setItems(listaUsuarios);
    }
}
